// javac ArrayAverage.java
//java ArrayAverage




/*
Case1: nums = [1, 2]
When the avg method is called with the array [1, 2], the input passes the precondition check since it is neither null nor empty. 
Then, the method calculates the sum of the elements (1 + 2 = 3) and divides it by the length of the array (2), 
and the result is 1.5. This value is returned by the method and assigned to the result variable in the main method. 
Therefore, the final value of the result is 1.5.

Case2: When nums = [] 
When the avg method is called with an empty array, the precondition check fails because the length of the array is 0. As a result, 
the method throws an EmptyArray exception, which is caught in the catch block of the main method. Since the exception is caught but 
no value is assigned to the result variable in the catch block, the result variable remains null.
 */




import java.util.ArrayList;
import java.util.List;

// exception to handle cases where the array is empty
class EmptyArray extends Exception {}

// exception to handle cases where the array contains negative numbers
class InvalidNumberException extends Exception {
    private final List<Integer> invalidIndices;

    public InvalidNumberException(List<Integer> invalidIndices) {
        this.invalidIndices = invalidIndices;
    }

    public List<Integer> getInvalidIndices() {
        return invalidIndices;
    }
}

// main class
public class ArrayAverage {
    
    // method to calculate the average of an array
    public static float avg(int[] nums) throws EmptyArray, InvalidNumberException {
        
        // check if the array is null or empty
        if (nums == null ||nums.length == 0) {
            // throw an exception 
            throw new EmptyArray();
        }

        // store indices of negative numbers
        List<Integer> invalidIndices = new ArrayList<>();
        for (int i = 0; i < nums.length; i++) {
            // check if the number is negative
            if (nums[i] < 0) {
                // add the index of the negative number
                invalidIndices.add(i);
            }
        }
        // throw an exception if there are any negative numbers
        if (!invalidIndices.isEmpty()) {
            throw new InvalidNumberException(invalidIndices);
        }

        // calculate the sum of the valid numbers
        int sum = 0;
        for (int num : nums) {
            sum += num;
        }
        // calculate and return the avg
        return (float) sum / nums.length;
    }

    // main method to test the avg method and handle exceptions
    public static void main(String[] args) {
        // negative 
        int[] nums = {1, -2, -3, 4};
        // positive
        //int[] nums = {1, 2, 3};
        // empty
        //int[] nums = {};

        try {
            // call the avg method 
            float result = avg(nums);
            System.out.println(result);
        } catch (EmptyArray e) {
            // handle the case where the array is empty
            System.out.println("The array is empty");
        } catch (InvalidNumberException e) {
            // handle the case where the array contains invalid
            List<Integer> invalidIndices = e.getInvalidIndices();
            for (int index : invalidIndices) {
                System.out.printf("The %d-th number %d in your array is invalid%n", index + 1, nums[index]);
            }
        }
    }
}
